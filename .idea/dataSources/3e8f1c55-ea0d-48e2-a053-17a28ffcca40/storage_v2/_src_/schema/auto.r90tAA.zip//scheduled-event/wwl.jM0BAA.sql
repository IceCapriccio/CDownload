create definer = root@localhost event wwl
  on schedule
    every '1' DAY
      starts '2018-12-20 00:00:00'
      ends '2019-01-20 00:00:00'
  on completion preserve
  enable
  comment '每秒进行数据更新'
do
  UPDATE `DB_csdn_vip_account` SET `today_use_limit` = FLOOR(140 + RAND()*4);

