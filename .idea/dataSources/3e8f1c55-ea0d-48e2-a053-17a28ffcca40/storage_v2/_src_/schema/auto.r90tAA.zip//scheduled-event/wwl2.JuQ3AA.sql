create definer = root@localhost event wwl2
  on schedule
    every '1' DAY
      starts '2018-12-19 00:00:00'
      ends '2019-01-21 00:00:00'
  on completion preserve
  enable
  comment '每日清除已下载次数'
do
  UPDATE `DB_csdn_vip_account` SET `today_use_times` = 0;

