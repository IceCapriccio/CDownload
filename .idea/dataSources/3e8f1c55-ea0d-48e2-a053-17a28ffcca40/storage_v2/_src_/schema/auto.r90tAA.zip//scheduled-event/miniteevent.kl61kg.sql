create definer = root@`%` event miniteEvent
  on schedule
    every '1' MINUTE
      starts '2018-12-20 16:00:28'
  on completion preserve
  enable
do
  insert into DB_csdn_vip_account values('111', '222');

